jQuery(document).ready(function ($) {
	$('#permalink-structure').change(function () {
		set_readonly_attr(this.value);
	});

	function set_readonly_attr(selected_value) {
		var custom_structure = $('#custom-structure');
		if (selected_value === 'plain') {
			custom_structure.val('');
			custom_structure.prop('readonly', true);
		} else if (selected_value === 'default') {
			custom_structure.val('frontend-publishing');
			custom_structure.prop('readonly', true);
		} else if (selected_value === 'custom') {
			custom_structure.prop('readonly', false);
			custom_structure.val('');
			custom_structure.focus();
		}
	}
});