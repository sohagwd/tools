<?php

namespace WPFEPP\Constants;

abstract class Permalinks_Settings {
	const PERMALINK_STRUCTURE = 'permalink_structure';
	const CUSTOM_STRUCTURE = 'custom_structure';
}