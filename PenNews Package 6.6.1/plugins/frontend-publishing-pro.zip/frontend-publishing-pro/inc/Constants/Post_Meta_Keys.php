<?php

namespace WPFEPP\Constants;

if ( ! defined( 'WPINC' ) ) {
	die;
}

abstract class Post_Meta_Keys {
	const FORM_ID = 'wpfepp_form_id';
}