<?php

namespace WPFEPP\Tabs;

if ( ! defined( 'WPINC' ) ) {
	die;
}

class Permalinks_Settings_Tab extends Backend_Tab {
	function __construct() {
		parent::__construct(
			'permalinks',
			__( 'Permalinks', 'frontend-publishing-pro' )
		);
	}

	function render() {
		$form = new \WPFEPP\Forms\Permalinks_Settings_Form();
		$form->render();
	}
}