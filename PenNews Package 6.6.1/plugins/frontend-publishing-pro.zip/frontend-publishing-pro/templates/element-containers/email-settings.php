<?php
if ( ! defined( 'WPINC' ) ) {
	die;
}

$elements = empty( $elements ) ? array() : $elements;
?>
<table class="form-table">
	<?php
	/*
	 * @var $elements \WPFEPP\Element[]
	 */
	foreach ( $elements as $element ) {
		$element->render();
	}
	?>
</table>
