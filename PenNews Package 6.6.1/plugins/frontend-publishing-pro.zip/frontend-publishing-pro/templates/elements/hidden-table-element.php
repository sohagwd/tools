<?php if ( ! defined( 'WPINC' ) ) {
	die;
} ?>
<tr>
	<td style="padding: 0;">
		<?php echo $field_html; ?>
	</td>
</tr>