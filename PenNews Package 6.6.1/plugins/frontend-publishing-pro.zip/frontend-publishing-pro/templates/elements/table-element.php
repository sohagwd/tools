<?php if ( ! defined( 'WPINC' ) ) {
	die;
} ?>
<tr>
	<th scope="row"><?php echo $label; ?></th>
	<td>
		<?php echo $field_html; ?>
		<p class="description"><?php echo $postfix_text; ?></p>
	</td>
</tr>