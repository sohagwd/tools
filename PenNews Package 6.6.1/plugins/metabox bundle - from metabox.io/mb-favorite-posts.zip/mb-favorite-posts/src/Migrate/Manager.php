<?php
namespace MBFP\Migrate;

class Manager {
	public function __construct() {
		$this->upgrade();
	}

	public function upgrade() {
		$check_migrate = get_option( 'mbfp_migrate' );

		if ( empty ( $check_migrate ) ) {
			$count = new Count;
			$count->migrate();

			// Update the DB
			update_option( 'mbfp_migrate', true );
		}
	}
}