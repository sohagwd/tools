<h2><?php esc_html_e( 'Log In', 'mb-favorite-posts' ); ?></h2>

<?php
do_action( 'mbfp_before_login_form' );

$label_submit        = esc_html__( 'Log In', 'mb-favorite-posts' );
$label_remember      = esc_html__( 'Remember me', 'mb-favorite-posts' );
$label_lost_password = esc_html__( 'Forgot your password?', 'mb-favorite-posts' );
$confirmation        = esc_html__( 'You are now logged in', 'mb-favorite-posts' );

$login_form = sprintf( '[mb_user_profile_login label_username="" label_password="" label_submit="%1$s" label_remember="%2$s" label_lost_password="%3$s" confirmation="%4$s"]', $label_submit, $label_remember, $label_lost_password, $confirmation );
echo do_shortcode( $login_form );

do_action( 'mbfp_after_login_form' );
