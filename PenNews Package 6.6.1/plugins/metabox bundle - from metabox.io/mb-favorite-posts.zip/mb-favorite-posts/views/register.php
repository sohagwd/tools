<h2><?php esc_html_e( 'Register', 'mb-favorite-posts' ); ?></h2>

<?php
do_action( 'mbfp_before_register_form' );

$submit        = esc_html__( 'Confirm', 'mb-favorite-posts' );
$confirmation  = esc_html__( 'Your account has been created successfully.', 'mb-favorite-posts' );
$register_form = sprintf( '[mb_user_profile_register email_as_username="true" password_strength="strong" id="dealer_registration" label_submit="%1$s" confirmation="%2$s"]', $submit, $confirmation );

echo do_shortcode( $register_form );

do_action( 'mbfp_after_register_form' );
