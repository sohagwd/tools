<?php

$fields = [];
$prefix = 'mb_testimonials_';
$files  = glob( __DIR__ . '/settings/*.php' );
foreach( $files as $file ) {
	$file = include $file;
	$fields = array_merge( $fields, $file );
}

return [
	'title'      => esc_html__( 'Settings', 'mb-testimonials' ),
	'post_types' => 'mb-testimonials',
	'tabs'       => [
		'display' => [
			'label' => esc_html__( 'Display', 'mb-testimonials' ),
		],
		'styling' => [
			'label' => esc_html__( 'Styling', 'mb-testimonials' ),
		],
	],
	'tab_style' => 'left',
	'fields'    => $fields,
];
