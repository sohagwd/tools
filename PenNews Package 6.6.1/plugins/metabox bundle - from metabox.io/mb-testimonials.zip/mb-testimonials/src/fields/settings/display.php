<?php

$tab = 'display';
return [
	[
		'id'    => $prefix . 'style',
		'class' => $prefix . 'style',
		'type'  => 'image_select',
		'options' => [
			'style-1' => MB_TESTIMONIALS_URL . 'assets/images/style-1.png',
			'style-2' => MB_TESTIMONIALS_URL . 'assets/images/style-2.png',
			'style-3' => MB_TESTIMONIALS_URL . 'assets/images/style-3.png',
			'style-4' => MB_TESTIMONIALS_URL . 'assets/images/style-4.png',
			'style-5' => MB_TESTIMONIALS_URL . 'assets/images/style-5.png',
			'style-6' => MB_TESTIMONIALS_URL . 'assets/images/style-6.png',
			'style-7' => MB_TESTIMONIALS_URL . 'assets/images/style-7.png',
		],
		'std' => 'style-1',
		'tab' => $tab,
	],
	[
		'type' => 'custom_html',
		'std'  => '
			<p class="mbt-customize-notice--1">' . esc_html__( 'Want to customize the template? ', 'mb-testimonials' ) . '<a href="" id= "mbt-customize-link">' . esc_html__( 'Click here', 'mb-testimonials' ) . '</a>.</p>
			<p class="mbt-customize-notice--2 notice notice-warning mbt-is-hidden">' . esc_html__( 'You have customized the template. Continue editing below.', 'mb-testimonials' ) . '</p>
		',
		'tab' => $tab,
	],
	[
		'type'     => 'custom_html',
		'callback' => [ $this, 'render_editors' ],
		'tab'      => $tab,
	],
	[
		'type' => 'custom_html',
		'std' => '<style>
			.mbt-customize-notice--2 {
				padding: 10px 15px;
			}
			.mb_testimonials_style .rwmb-image-select {
				padding: 0;
			}
			.mbt-customize-notices {
				display: flex;
			}
			.rwmb-image-select {
				width: 120px;
				height: auto;
			}
			.rwmb-image-select img {
				display: block;
			}
		</style>'
	],
];
