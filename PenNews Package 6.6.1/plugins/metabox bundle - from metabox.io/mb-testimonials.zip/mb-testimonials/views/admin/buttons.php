<div class="mbt-buttons">
    <button id="mbt-button--cancel" type="button" class="button button-link button-link-delete"><?php esc_html_e( 'Cancel', 'mb-testimonials' ); ?></button>
    <button id="mbt-button--reset" type="button" class="button button-primary"><?php esc_html_e( 'Reset', 'mb-testimonials' ); ?></button>
</div>
