<div class="widefat">
	<p style="margin-top: 0"><?php esc_html_e( 'Click the buttons below to insert testimonial elements.', 'mb-testimonials' ) ?></p>
	<div class="mbt-components" id="mbt-components">
		<!-- render button fields here -->
	</div>
</div>
