<div class="mbt-tab__pane is-active" data-tab="template-editor">
	<textarea class="widefat" rows="20" id="mbt-post-content" name="post_content"><?= esc_textarea( get_post()->post_content ) ?></textarea>
</div>

<div class="mbt-tab__pane" data-tab="css-editor">
	<textarea class="widefat" rows="20" id="mbt-post-excerpt" name="post_excerpt"><?= esc_textarea( get_post()->post_excerpt ) ?></textarea>
</div>
