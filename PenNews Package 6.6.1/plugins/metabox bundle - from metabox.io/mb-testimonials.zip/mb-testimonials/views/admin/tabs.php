<ul class="mbt-tab__nav">
	<li class="mbt-tab__link is-active" data-tab="template-editor"><?php esc_html_e( 'Template', 'auto-listings' ) ?></li>
	<li class="mbt-tab__link" data-tab="css-editor"><?php esc_html_e( 'CSS', 'auto-listings' ) ?></li>
</ul>
