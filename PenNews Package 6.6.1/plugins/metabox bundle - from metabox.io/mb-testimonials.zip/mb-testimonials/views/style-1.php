{{ subject_rating }}
{{ content }}
{{ image }}
<div class="mbt-author-info">
	{{ name }}
	{{ position }}
	{{ review_link }}
</div>
