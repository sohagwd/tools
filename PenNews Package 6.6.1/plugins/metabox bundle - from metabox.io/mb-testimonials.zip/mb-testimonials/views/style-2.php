{{ image }}
{{ subject_rating }}
{{ content }}
<div class="mbt-author-info">
	{{ name }}
	{{ position }}
	{{ review_link }}
</div>
