<div class="mbt-text">
	{{ subject_rating }}
	{{ content }}
</div>
<div class="mbt-image-wrapper">
	{{ image }}
</div>
<div class="mbt-author-info">
	{{ name }}
	{{ position }}
	{{ review_link }}
</div>
