<div class="mbt-testimonial">
	<div class="mbt-text">
		{{ subject_rating }}
		{{ content }}
		{{ image }}
		<div class="mbt-author-info">
			{{ name }}
			{{ position }}
			{{ review_link }}
		</div>
	</div>
</div>
