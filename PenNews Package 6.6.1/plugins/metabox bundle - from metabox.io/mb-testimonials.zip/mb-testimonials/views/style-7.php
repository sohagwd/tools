<div class="mbt-text">
	{{ content }}
	<div class="mbt-image-wrapper">
		{{ image }}
	</div>
	<div class="mbt-author-info">
		{{ name }}
		{{ position }}
		{{ review_link }}
	</div>
	<div class="mbt-subject-rating">
		{{ rating }}
	</div>
</div>
