<div class="mbt-content">
    <?= wp_kses_post( $data->content ); ?>
</div>
