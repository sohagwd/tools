<?= wp_get_attachment_image( $data->author_image, 'full', false, [ 'class' => 'mbt-image' ] );
