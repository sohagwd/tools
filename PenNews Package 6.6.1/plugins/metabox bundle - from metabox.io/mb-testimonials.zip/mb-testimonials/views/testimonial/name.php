<div class="mbt-name">
	<?= esc_html( $data->author_name ); ?>
</div>
