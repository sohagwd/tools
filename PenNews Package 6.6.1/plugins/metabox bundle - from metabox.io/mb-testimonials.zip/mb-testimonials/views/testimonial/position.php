<div class="mbt-position">
	<?= esc_html( $data->author_position ); ?>
</div>
