<div class="mbt-rating">
	<?php for( $i = 1; $i <= absint( $data->rating ); $i++ ) : ?>
		<span class="mbt-rating__star"></span>
	<?php endfor; ?>
</div>
