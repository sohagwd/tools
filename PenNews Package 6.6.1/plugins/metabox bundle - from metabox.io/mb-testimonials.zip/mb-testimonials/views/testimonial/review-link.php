<a class="mbt-review-link" href="<?= esc_url( $data->url ); ?>">
    <?= esc_html( $data->text ); ?>
</a>
