<div class="mbt-subject-rating">
	<?php
	MBTestimonials\Helper::get_template_part( 'testimonial/subject', [ 'subject' => $data->subject ] );
	MBTestimonials\Helper::get_template_part( 'testimonial/rating', [ 'rating' => $data->rating ] );
	?>
</div>
