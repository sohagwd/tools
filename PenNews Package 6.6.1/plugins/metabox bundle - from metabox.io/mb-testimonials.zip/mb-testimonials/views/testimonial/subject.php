<div class="mbt-subject">
	<?= esc_html( $data->subject ); ?>
</div>
