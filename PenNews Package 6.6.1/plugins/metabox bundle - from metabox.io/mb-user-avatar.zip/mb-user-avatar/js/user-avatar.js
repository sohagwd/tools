( function( $ ) {
	$( '.user-profile-picture' ).closest( 'table' ).after( $( '.mb-user-avatar' ) );
}( jQuery ) );
