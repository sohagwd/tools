<?php
namespace MBUA;

class Assets {
    public function __construct () {
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ] );
    }

    public function enqueue() {
        $screen = get_current_screen();
        if ( in_array( $screen->id, [ 'profile', 'user-edit' ] ) ) {
            wp_enqueue_script( 'mbua-script', MBUA_URL . 'js/user-avatar.js', ['jquery'], '1.0.0', true );
        }
    }
}
