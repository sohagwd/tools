<?php
namespace MBUA;

class Fields {
	public function __construct () {
		add_filter( 'rwmb_meta_boxes', [ $this, 'register_user_avatar' ] );
	}

	public function register_user_avatar( $meta_boxes ) {
		$meta_boxes[] = [
			'title'  => ' ',
			'type'   => 'user',
			'class'  => 'mb-user-avatar',
			'fields' => [
				[
					'name' => __( 'Custom Profile Picture', 'mb-user-avatar' ),
					'id'   => 'mbua_avatar',
					'type' => 'single_image',
				],
			],
		];

		return $meta_boxes;
	}
}
