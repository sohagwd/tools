<?php
class RWMB_User_Storage extends \RWMB_Base_Storage {
	protected $object_type = 'user';
}
