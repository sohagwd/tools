jQuery( function ( $ ) {
	'use strict';

} );