<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
add_filter( 'rwmb_meta_boxes', 'penci_amp_register_meta_boxes' );

function penci_amp_register_meta_boxes( $meta_boxes ) {
	$meta_boxes[] = array(
		'id'         => 'penci-amp-settings',
		'title'      => esc_html__( 'Penci AMP Settings', 'pennews' ),
		'post_types' => array( 'post', 'page','product' ),
		'context'    => 'side',
		'priority'   => 'default',
		'fields'     => array(
			array(
				'id'   => 'penci_dis_amp_onpost',
				'name' => esc_html__( 'Disable amp version', 'pennews' ),
				'type' => 'checkbox',
			),
		)
	);

	return $meta_boxes;
}