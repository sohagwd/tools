<form role="search" class="penci-search-form clearfix <?php echo ! get_search_query( false ) ? 'empty' : ''; ?>" action="<?php echo esc_url( penci_amp_get_site_url() ) ?>/" target="_top" novalidate>

	<label class="search-label">
		<?php echo penci_amp_get_setting( 'penci_amp_search_on_site' ); ?>
	</label>

	<div class="search-input">
		<input type="search" class="search-field" placeholder="<?php echo penci_amp_get_setting( 'penci_amp_search_input_placeholder' ); ?>" value="<?php the_search_query() ?>" name="s"/>
		<input type="submit" class="search-submit button" value="<?php echo penci_amp_get_setting( 'penci_amp_search_button' ); ?>"/>
	</div>

</form>