
<amp-sidebar id="penci_sidebar" class="mobile-sidebar" layout="nodisplay" side="<?php echo ( is_rtl() ? 'right' : 'left' ); ?>">
	<button id="close-sidebar-nav" on="tap:penci_sidebar.close" class="ampstart-btn caps m2"><i class="fa fa-close"></i></button>
	<div id="sidebar-nav-logo">
		<?php
		$sidebar_logo = penci_amp_get_branding_info( 'sidebar' );

		if ( empty( $sidebar_logo['logo-tag'] ) && $sidebar_logo['name'] ) {
			$sidebar_logo = penci_amp_get_branding_info( $pos = 'header' );
		}

		?>
		<a href="<?php echo esc_url( penci_amp_get_site_url() ); ?>"
		   class="sidebar-branding <?php echo ! empty( $sidebar_logo['logo-tag'] ) ? 'penci-amp-site-icon sidebar-image-logo' : 'text-logo'; ?> ">
			<?php
			if ( ! empty( $sidebar_logo['logo-tag'] ) ) {
				echo $sidebar_logo['logo-tag']; // escaped before
			} else {
				echo $sidebar_logo['name']; // escaped before
			}
			?>
		</a>
	</div>
	<div class="header-social sidebar-nav-social">
		<div class="inner-header-social">
			<?php if( function_exists( 'penci_list_socail_media' ) ) :  penci_list_socail_media(); endif;  ?>
		</div>
	</div>

	<?php
	$theme_location = '';
	if ( has_nav_menu( 'penci-amp-sidebar-nav' ) ) :
		$theme_location = 'penci-amp-sidebar-nav';
	elseif( has_nav_menu( 'menu-1' ) ):
		$theme_location = 'menu-1';
	endif;

	if( $theme_location ) {
		wp_nav_menu( array(
			'theme_location' => $theme_location,
			'container'      => '',
			'items_wrap'     => '<nav id="%1$s" itemscope itemtype="http://schema.org/SiteNavigationElement" class="mobile-navigation %2$s">%3$s</nav>',
			'fallback_cb'    => 'penci_amp_menu_fallback',
			'walker'         => class_exists( 'Penci_AMP_Menu_Walker' ) ? new Penci_AMP_Menu_Walker() : '',
			'menu_id'        => 'primary-menu-mobile',
			'menu_class'     => 'primary-menu-mobile penci-amp-menu',
		) );
	}
	?>
</amp-sidebar>

