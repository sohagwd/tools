<?php
/**
 * Social buttons class.
 */

$list_social = array( 'facebook', 'twitter', 'google_plus', 'pinterest', 'linkedin', 'tumblr', 'reddit', 'stumbleupon','whatsapp','telegram','email','digg','vk','line','viber' );
$option_prefix = 'penciamp_hide_share_';

foreach ( $list_social as $k => $item ) {
	if ( penci_amp_get_setting( $option_prefix . $item ) ) {
		unset( $list_social[ $k ] );
	}
}
if( empty( $list_social ) ) {
	return;
}

echo '<span class="penci-social-buttons penci-social-share-footer">';
echo '<span class="penci-social-share-text">' . penci_amp_get_setting( 'penci-social-share-text' ) . '</span>';
$link     = get_permalink( );
$text     = get_the_title();
$img_link = get_the_post_thumbnail_url();


Penci_AMP_Social_Share::get_social_share( $list_social );

echo '</span>';