/* global tinymce */
( function() {
	tinymce.PluginManager.add( 'penci_sml_mce', function( editor ) {
		editor.addButton( 'penci_sml_mce_button', {
			title: 'Select Smart Lists Shortcode',
			text: 'Smart Lists',
			icon : 'wp_code',
			type : 'menubutton',
			menu : [
				{
					text: 'List Start',
					onclick: function() {
						wp.mce.penci_sml_start.rendershortcode(editor);
					}
				},
				{
					text: 'List End',
					onclick: function() {
						wp.mce.penci_sml_end.rendershortcode(editor);
					}
				}
			]
		} );

	});
})();
