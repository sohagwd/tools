<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$style            = isset( $mart_list_data['style'] ) ? $mart_list_data['style'] : 'sml-s1';
$sort             = isset( $mart_list_data['sort'] ) ? $mart_list_data['sort'] : 'asc';
$msl_items        = isset( $mart_list_data['msl_items'] ) ? $mart_list_data['msl_items'] : array();
$msl_items_number = isset( $mart_list_data['msl_items_number'] ) ? $mart_list_data['msl_items_number'] : 0;

Penci_Smart_Lists_Helper::render_start_sml_div( $mart_list_data, $mart_list_style, false );
Penci_Smart_Lists_Helper::render_before_sml_wrap( $style, $sort, true );
$ad_i  = 1;
$current_number = 0;
foreach ( $msl_items as $item_key => $msl_item ) {
	echo '<div class="penci-sml-item">';
	$current_number = Penci_Smart_Lists_Helper::add_number_order( $current_number, $msl_items_number, $sort );
	Penci_Smart_Lists_Helper::render_title_item( $msl_item, $current_number, true );
	Penci_Smart_Lists_Helper::render_image_item( $msl_item );

	if( ! empty( $msl_item['content'] ) ){
		echo '<div class="penci-sml-content penci-sml-p0">' . $msl_item['content'] . '</div>';
	}

	echo '</div>';

	$code_ads_s6_12 = get_theme_mod( 'penci_sml_ads_s6_12' );
	$order_show_ads = get_theme_mod( 'penci_sml_ads_xs6_12' ) ? get_theme_mod( 'penci_sml_ads_xs6_12' ) : 3;
	if ( $order_show_ads == $ad_i && $code_ads_s6_12 ) {
		echo '<div class="penci-google-adsense penci_sml_ads_s6_12 penci-sml-item">' . do_shortcode( $code_ads_s6_12 ) . '</div>';
	}

	$ad_i ++;
}
?>
<?php
Penci_Smart_Lists_Helper::render_after_sml_wrap(  true );

