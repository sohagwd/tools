<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$style            = isset( $mart_list_data['style'] ) ? $mart_list_data['style'] : 'sml-s1';
$sort             = isset( $mart_list_data['sort'] ) ? $mart_list_data['sort'] : 'asc';
$msl_items        = isset( $mart_list_data['msl_items'] ) ? $mart_list_data['msl_items'] : array();
$msl_items_number = isset( $mart_list_data['msl_items_number'] ) ? $mart_list_data['msl_items_number'] : 0;

$paged =  1;
if( get_query_var( 'paged' ) ){
	$paged = get_query_var( 'paged' );
}elseif (  get_query_var( 'page' ) ){
	$paged = get_query_var( 'page' );
}

if( ! isset( $msl_items[  $paged - 1 ] ) ){
	$paged = 1;
}

$key_current_item = $paged -1;

if( ! isset( $msl_items[ $key_current_item ] ) ){
	return;
}
$msl_item = $msl_items[ $key_current_item ];

Penci_Smart_Lists_Helper::render_start_sml_div( $mart_list_data, $mart_list_style );
Penci_Smart_Lists_Helper::render_before_sml_wrap( $style, $sort, true );
Penci_Smart_Lists_Helper::markup_pagination_2( $paged, $msl_items_number, $msl_items, 'penci-sml-navtop','style-17' );
echo '<div class="penci-sml-item">';
Penci_Smart_Lists_Helper::render_image_item( $msl_item );
Penci_Smart_Lists_Helper::render_title_item( $msl_item, $paged );
Penci_Smart_Lists_Helper::render_google_adsense( 'penci_sml_ads_s13_17' );

if( ! empty( $msl_item['content'] ) ){
	echo '<div class="penci-sml-content penci-sml-p0">' . $msl_item['content'] . '</div>';
}
echo '</div>';
Penci_Smart_Lists_Helper::markup_pagination( $paged, $msl_items_number, $msl_items, 'penci-sml-navbt' );
?>
<?php
Penci_Smart_Lists_Helper::render_after_sml_wrap(  true );

