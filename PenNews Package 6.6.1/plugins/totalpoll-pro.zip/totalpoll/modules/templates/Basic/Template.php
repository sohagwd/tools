<?php

namespace TotalPoll\Modules\Templates\Basic;
! defined( 'ABSPATH' ) && exit();


class Template extends \TotalPoll\Modules\Template {
	protected $root = __FILE__;
}