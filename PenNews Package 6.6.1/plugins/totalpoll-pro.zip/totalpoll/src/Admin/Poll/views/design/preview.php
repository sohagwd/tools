<?php ! defined( 'ABSPATH' ) && exit(); ?><div class="totalpoll-design-preview">
    <div class="totalpoll-design-preview-device">
        <iframe class="totalpoll-design-preview-iframe" ng-style="$ctrl.getDeviceScaleAttributes()"></iframe>
    </div>
</div>
