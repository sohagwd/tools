<?php ! defined( 'ABSPATH' ) && exit(); ?><customizer-control
	type="typography"
	label="<?php _e( 'Typography', 'totalpoll' ); ?>"
	ng-model="$root.settings.design.text"></customizer-control>