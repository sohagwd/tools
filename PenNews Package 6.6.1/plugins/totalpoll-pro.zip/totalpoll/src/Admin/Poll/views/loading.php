<?php ! defined( 'ABSPATH' ) && exit(); ?><div class="totalpoll-loading" ng-if="false">
	<div class="totalpoll-loading-spinner"></div>
	<?php _e( 'Loading...', 'totalpoll' ); ?>
</div>