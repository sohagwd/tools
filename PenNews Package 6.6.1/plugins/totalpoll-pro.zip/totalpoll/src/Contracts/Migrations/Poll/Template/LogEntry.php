<?php

namespace TotalPoll\Contracts\Migrations\Poll\Template;
! defined( 'ABSPATH' ) && exit();


/**
 * Interface LogEntry
 * @package TotalPoll\Contracts\Migrations\Poll\Template
 */
interface LogEntry extends Template {

}