<?php

namespace TotalPoll\Modules;
! defined( 'ABSPATH' ) && exit();


/**
 * Extension.
 * @package TotalPoll\Modules
 */
abstract class Extension extends \TotalPollVendors\TotalCore\Modules\Extension {

}